"use client"

import * as React from "react"
import { toast } from "@/components/ui/use-toast"
import {
  Download,
  FileText,
  CalendarIcon,
  CheckCircle,
  Plus,
  FileDown,
  FileUp,
  Search,
  Filter,
  X,
  ChevronDown,
  ChevronUp,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  CloudUpload,
  AlertCircle,
  FileCheck,
} from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { format } from "date-fns"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Sample lead data with tags
const sampleLeads = [
  {
    id: 1,
    name: "Arjun Kumar",
    email: "arjun.kumar@srmist.edu.in",
    mobile: "+91 9876543210",
    college: "SRM Institute of Science and Technology",
    department: "Computer Science",
    batch: "2021-2025",
    domain: "AI/ML",
    eventSource: "Workshop",
    state: "Tamil Nadu",
    country: "India",
    institutionType: "Private",
    university: "SRM Institute",
    yearAdmission: "2021",
    modeOfStudy: "Offline",
    eventType: "Workshop",
    cityDistrict: "Chennai",
    branch: "T Nagar",
    areasOfInterest: ["AI/ML", "Deep Learning", "Python"],
    tags: [
      "#Student",
      "#ComputerScience",
      "#Batch2021",
      "#Workshop",
      "#TamilNadu",
      "#India",
      "#Chennai",
      "#AI",
      "#DeepLearning",
      "#Python",
      "#ModeOffline",
    ],
    addedOn: "2024-01-15T10:30:00Z",
    status: "Hot",
  },
  {
    id: 2,
    name: "Priya Sharma",
    email: "priya.sharma@vit.ac.in",
    mobile: "+91 8765432109",
    college: "Vellore Institute of Technology",
    department: "Electronics",
    batch: "2022-2026",
    domain: "IoT",
    eventSource: "Campus Drive",
    state: "Tamil Nadu",
    country: "India",
    institutionType: "Private",
    university: "VIT",
    yearAdmission: "2022",
    modeOfStudy: "Hybrid",
    eventType: "Campus Drive",
    cityDistrict: "Vellore",
    branch: "Chemmencerry",
    areasOfInterest: ["IoT", "Embedded Systems", "Arduino"],
    tags: ["#Student", "#Electronics", "#Batch2022", "#CampusDrive", "#TamilNadu", "#India", "#IoT", "#ModeHybrid"],
    addedOn: "2024-01-14T14:20:00Z",
    status: "Warm",
  },
  {
    id: 3,
    name: "Dr. Rajesh Menon",
    email: "rajesh.menon@cusat.ac.in",
    mobile: "+91 7654321098",
    college: "Cochin University of Science and Technology",
    department: "AI/ML",
    batch: "Faculty",
    domain: "Data Science",
    eventSource: "FDP",
    state: "Kerala",
    country: "India",
    institutionType: "Government",
    university: "CUSAT",
    yearAdmission: "2010",
    modeOfStudy: "Online",
    eventType: "FDP",
    cityDistrict: "Kochi",
    branch: "Kochi",
    areasOfInterest: ["Data Science", "Machine Learning", "Research"],
    tags: [
      "#Faculty",
      "#AI/ML",
      "#FDP",
      "#Kerala",
      "#India",
      "#Kochi",
      "#DataScience",
      "#ModeOnline",
      "#GovernmentInstitution",
    ],
    addedOn: "2024-01-13T09:15:00Z",
    status: "Hot",
  },
  {
    id: 4,
    name: "Sneha Reddy",
    email: "sneha.reddy@jntuh.ac.in",
    mobile: "+91 6543210987",
    college: "JNTU Hyderabad",
    department: "Data Science",
    batch: "2023-2027",
    domain: "Data Analytics",
    eventSource: "Online Course",
    state: "Telangana",
    country: "India",
    institutionType: "Government",
    university: "JNTU",
    yearAdmission: "2023",
    modeOfStudy: "Online",
    eventType: "Online Course",
    cityDistrict: "Hyderabad",
    branch: "Ameerpet",
    areasOfInterest: ["Data Analytics", "Power BI", "Python"],
    tags: [
      "#Student",
      "#DataScience",
      "#Batch2023",
      "#OnlineCourse",
      "#Telangana",
      "#India",
      "#Hyderabad",
      "#DataAnalytics",
      "#PowerBI",
      "#Python",
      "#ModeOnline",
    ],
    addedOn: "2024-01-12T16:45:00Z",
    status: "Warm",
  },
  {
    id: 5,
    name: "Mohammed Ali",
    email: "mohammed.ali@manipal.edu",
    mobile: "+91 5432109876",
    college: "Manipal Institute of Technology",
    department: "Robotics",
    batch: "2020-2024",
    domain: "Robotics",
    eventSource: "Project Expo",
    state: "Karnataka",
    country: "India",
    institutionType: "Private",
    university: "Manipal",
    yearAdmission: "2020",
    modeOfStudy: "Offline",
    eventType: "Project Expo",
    cityDistrict: "Manipal",
    branch: "Bangalore",
    areasOfInterest: ["Robotics", "ROS", "Arduino"],
    tags: [
      "#Student",
      "#Robotics",
      "#Alumni",
      "#ProjectExpo",
      "#Karnataka",
      "#India",
      "#Robotics",
      "#ROS",
      "#ModeOffline",
    ],
    addedOn: "2024-01-11T11:30:00Z",
    status: "Cold",
  },
]

// Tag categories for filtering
const tagCategories = {
  academic: {
    title: "🧑‍🎓 Academic Tags",
    tags: [
      "#Student",
      "#Staff",
      "#Faculty",
      "#IndustryProfessional",
      "#ComputerScience",
      "#Electronics",
      "#Mechanical",
      "#AI/ML",
      "#DataScience",
      "#IoT",
      "#Robotics",
      "#VLSI",
      "#Batch2021",
      "#Batch2022",
      "#Batch2023",
      "#Alumni",
    ],
  },
  event: {
    title: "📅 Event Tags",
    tags: [
      "#Workshop",
      "#Masterclass",
      "#Referral",
      "#CampusDrive",
      "#OnlineCourse",
      "#ProjectExpo",
      "#Hackathon",
      "#FDP",
    ],
  },
  region: {
    title: "🌐 Region & Institution Tags",
    tags: [
      "#TamilNadu",
      "#Kerala",
      "#Karnataka",
      "#Telangana",
      "#Maharashtra",
      "#India",
      "#SriLanka",
      "#UAE",
      "#Thiruporur",
      "#Chennai",
      "#Hyderabad",
      "#Bangalore",
      "#Pune",
      "#PrivateInstitution",
      "#GovernmentInstitution",
      "#Autonomous",
      "#DeemedUniversity",
    ],
  },
  domain: {
    title: "📚 Domain / Interest Tags",
    tags: [
      "#AI",
      "#DeepLearning",
      "#DataAnalytics",
      "#Python",
      "#R",
      "#TensorFlow",
      "#PowerBI",
      "#ROS",
      "#JetsonNano",
      "#FPGA",
      "#ResponsibleAI",
      "#BusinessTools",
      "#AgenticAI",
    ],
  },
  metadata: {
    title: "🎓 Academic Metadata Tags",
    tags: ["#ModeOnline", "#ModeOffline", "#ModeHybrid", "#Admitted2021", "#Graduated2024", "#Grad2025"],
  },
}

interface DataManagementPageProps {
  showCreateForm: boolean
  setShowCreateForm: (show: boolean) => void
  formData: any
  setFormData: (data: any) => void
  dragActive: boolean
  setDragActive: (active: boolean) => void
}

export function DataManagementPage({
  showCreateForm,
  setShowCreateForm,
  formData,
  setFormData,
  dragActive,
  setDragActive,
}: DataManagementPageProps) {
  // Filter states
  const [searchQuery, setSearchQuery] = React.useState("")
  const [dateRange, setDateRange] = React.useState<{ from?: Date; to?: Date }>({})
  const [selectedTags, setSelectedTags] = React.useState<string[]>([])
  const [filteredLeads, setFilteredLeads] = React.useState(sampleLeads)
  const [selectedLeads, setSelectedLeads] = React.useState<number[]>([])
  const [expandedCategories, setExpandedCategories] = React.useState<string[]>(["academic"])
  const [currentPage, setCurrentPage] = React.useState(1)
  const [itemsPerPage] = React.useState(10)
  const [sortField, setSortField] = React.useState<string>("addedOn")
  const [sortDirection, setSortDirection] = React.useState<"asc" | "desc">("desc")

  // File upload states
  const [uploadedFile, setUploadedFile] = React.useState<File | null>(null)
  const [uploadError, setUploadError] = React.useState<string>("")
  const [isDragOver, setIsDragOver] = React.useState(false)

  // Date range presets
  const datePresets = [
    { label: "Last 7 Days", days: 7 },
    { label: "Last 30 Days", days: 30 },
    { label: "Last 90 Days", days: 90 },
  ]

  // Filter leads based on search, tags, and date range
  React.useEffect(() => {
    let filtered = sampleLeads

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(
        (lead) =>
          lead.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          lead.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          lead.college.toLowerCase().includes(searchQuery.toLowerCase()) ||
          lead.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
          lead.eventType.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Tag filter
    if (selectedTags.length > 0) {
      filtered = filtered.filter((lead) => selectedTags.every((tag) => lead.tags.includes(tag)))
    }

    // Date range filter
    if (dateRange.from || dateRange.to) {
      filtered = filtered.filter((lead) => {
        const leadDate = new Date(lead.addedOn)
        if (dateRange.from && leadDate < dateRange.from) return false
        if (dateRange.to && leadDate > dateRange.to) return false
        return true
      })
    }

    // Sort
    filtered.sort((a, b) => {
      let aValue = a[sortField as keyof typeof a]
      let bValue = b[sortField as keyof typeof b]

      if (sortField === "addedOn") {
        aValue = new Date(aValue as string).getTime()
        bValue = new Date(bValue as string).getTime()
      }

      if (sortDirection === "asc") {
        return aValue > bValue ? 1 : -1
      } else {
        return aValue < bValue ? 1 : -1
      }
    })

    setFilteredLeads(filtered)
    setCurrentPage(1)
  }, [searchQuery, selectedTags, dateRange, sortField, sortDirection])

  const handleExportCSV = () => {
    const leadsToExport =
      selectedLeads.length > 0 ? filteredLeads.filter((lead) => selectedLeads.includes(lead.id)) : filteredLeads

    toast({
      title: "Export Started",
      description: `Exporting ${leadsToExport.length} leads to CSV...`,
    })
  }

  const handleUploadLeads = () => {
    toast({
      title: "Upload Ready",
      description: "Select a CSV file to upload leads.",
    })
  }

  const handleDatePreset = (days: number) => {
    const to = new Date()
    const from = new Date()
    from.setDate(from.getDate() - days)
    setDateRange({ from, to })
  }

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]))
  }

  const removeTag = (tag: string) => {
    setSelectedTags((prev) => prev.filter((t) => t !== tag))
  }

  const toggleCategory = (category: string) => {
    setExpandedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const currentPageLeads = filteredLeads.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
      setSelectedLeads(currentPageLeads.map((lead) => lead.id))
    } else {
      setSelectedLeads([])
    }
  }

  const handleSelectLead = (leadId: number, checked: boolean) => {
    if (checked) {
      setSelectedLeads((prev) => [...prev, leadId])
    } else {
      setSelectedLeads((prev) => prev.filter((id) => id !== leadId))
    }
  }

  // File upload handlers
  const handleFileUpload = (file: File) => {
    setUploadError("")

    // Validate file type
    if (!file.name.toLowerCase().endsWith(".csv")) {
      setUploadError("Only CSV files are supported. Please upload a .csv file.")
      return
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setUploadError("File size must be less than 10MB.")
      return
    }

    setUploadedFile(file)
    toast({
      title: "File Uploaded Successfully",
      description: `${file.name} (${(file.size / 1024).toFixed(1)} KB) is ready for processing.`,
    })
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
    setDragActive(false)

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileUpload(files[0])
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
    setDragActive(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
    setDragActive(false)
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      handleFileUpload(files[0])
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  // Pagination
  const totalPages = Math.ceil(filteredLeads.length / itemsPerPage)
  const currentLeads = filteredLeads.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (
    <div className="space-y-6">
      {/* Section 1: Top Action Bar */}
      <div className="sticky top-0 z-10 bg-white/95 dark:bg-gray-900/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-gray-900/60 border-b border-gray-200 dark:border-gray-700 p-4 -m-6 mb-6 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Lead Management</h2>
          <div className="flex flex-wrap items-center gap-2">
            <Button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Lead
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportCSV}
              className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 bg-transparent"
            >
              <FileDown className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 bg-transparent"
            >
              <FileText className="h-4 w-4 mr-2" />
              View Reports
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleUploadLeads}
              className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 bg-transparent"
            >
              <FileUp className="h-4 w-4 mr-2" />
              Upload Leads
            </Button>
          </div>
        </div>
      </div>

      {/* Section 2: Create New Lead Form */}
      {showCreateForm && (
        <Card className="shadow-lg border border-gray-200 dark:border-gray-700">
          <CardHeader className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
            <CardTitle className="text-xl text-gray-900 dark:text-white">Create New Lead</CardTitle>
            <CardDescription className="text-gray-600 dark:text-gray-400">
              Enter lead information to add to your pipeline
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <form className="space-y-6">
              {/* Basic Information */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    placeholder="Enter full name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter email address"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Mobile Number
                  </Label>
                  <Input
                    id="phone"
                    placeholder="Enter mobile number"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="staffStudent" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Staff / Student *
                  </Label>
                  <Select
                    value={formData.staffStudent}
                    onValueChange={(value) => setFormData({ ...formData, staffStudent: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="staff">Staff</SelectItem>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="faculty">Faculty</SelectItem>
                      <SelectItem value="industry">Industry Professional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="college" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    College
                  </Label>
                  <Input
                    id="college"
                    placeholder="Enter college name"
                    value={formData.college}
                    onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                    className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Department
                  </Label>
                  <Select
                    value={formData.department}
                    onValueChange={(value) => setFormData({ ...formData, department: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="computer-science">Computer Science</SelectItem>
                      <SelectItem value="electronics">Electronics</SelectItem>
                      <SelectItem value="mechanical">Mechanical</SelectItem>
                      <SelectItem value="ai-ml">AI/ML</SelectItem>
                      <SelectItem value="data-science">Data Science</SelectItem>
                      <SelectItem value="iot">IoT</SelectItem>
                      <SelectItem value="robotics">Robotics</SelectItem>
                      <SelectItem value="vlsi">VLSI</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="batch" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Batch
                  </Label>
                  <Select value={formData.batch} onValueChange={(value) => setFormData({ ...formData, batch: value })}>
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select batch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2021-2025">2021–2025</SelectItem>
                      <SelectItem value="2022-2026">2022–2026</SelectItem>
                      <SelectItem value="2023-2027">2023–2027</SelectItem>
                      <SelectItem value="alumni">Alumni</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="domain" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Domain
                  </Label>
                  <Select
                    value={formData.domain}
                    onValueChange={(value) => setFormData({ ...formData, domain: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select domain" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ai">AI</SelectItem>
                      <SelectItem value="data-analytics">Data Analytics</SelectItem>
                      <SelectItem value="embedded-systems">Embedded Systems</SelectItem>
                      <SelectItem value="robotics">Robotics</SelectItem>
                      <SelectItem value="edge-computing">Edge Computing</SelectItem>
                      <SelectItem value="vlsi">VLSI</SelectItem>
                      <SelectItem value="cybersecurity">Cybersecurity</SelectItem>
                      <SelectItem value="business-tools">Business Tools</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="eventSource" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Event / Program / Source
                  </Label>
                  <Select
                    value={formData.eventSource}
                    onValueChange={(value) => setFormData({ ...formData, eventSource: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select source" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="workshop">Workshop</SelectItem>
                      <SelectItem value="masterclass">Masterclass</SelectItem>
                      <SelectItem value="industrial-visit">Industrial Visit</SelectItem>
                      <SelectItem value="online-course">Online Course</SelectItem>
                      <SelectItem value="lms-registration">LMS Registration</SelectItem>
                      <SelectItem value="referral">Referral</SelectItem>
                      <SelectItem value="campus-drive">Campus Drive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Location Information */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-2">
                  <Label htmlFor="state" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    State
                  </Label>
                  <Select value={formData.state} onValueChange={(value) => setFormData({ ...formData, state: value })}>
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="tamil-nadu">Tamil Nadu</SelectItem>
                      <SelectItem value="kerala">Kerala</SelectItem>
                      <SelectItem value="karnataka">Karnataka</SelectItem>
                      <SelectItem value="andhra-pradesh">Andhra Pradesh</SelectItem>
                      <SelectItem value="telangana">Telangana</SelectItem>
                      <SelectItem value="maharashtra">Maharashtra</SelectItem>
                      <SelectItem value="others">Others</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="country" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Country
                  </Label>
                  <Select
                    value={formData.country}
                    onValueChange={(value) => setFormData({ ...formData, country: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="india">India</SelectItem>
                      <SelectItem value="sri-lanka">Sri Lanka</SelectItem>
                      <SelectItem value="bangladesh">Bangladesh</SelectItem>
                      <SelectItem value="uae">UAE</SelectItem>
                      <SelectItem value="others">Others</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cityDistrict" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    City / District
                  </Label>
                  <Select
                    value={formData.cityDistrict}
                    onValueChange={(value) => setFormData({ ...formData, cityDistrict: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select city/district" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="thiruporur">Thiruporur</SelectItem>
                      <SelectItem value="chennai">Chennai</SelectItem>
                      <SelectItem value="coimbatore">Coimbatore</SelectItem>
                      <SelectItem value="madurai">Madurai</SelectItem>
                      <SelectItem value="trichy">Trichy</SelectItem>
                      <SelectItem value="hyderabad">Hyderabad</SelectItem>
                      <SelectItem value="bangalore">Bangalore</SelectItem>
                      <SelectItem value="kochi">Kochi</SelectItem>
                      <SelectItem value="pune">Pune</SelectItem>
                      <SelectItem value="others">Others</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="branch" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Branch
                  </Label>
                  <Select
                    value={formData.branch}
                    onValueChange={(value) => setFormData({ ...formData, branch: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select branch" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="t-nagar">T Nagar</SelectItem>
                      <SelectItem value="chemmencerry">Chemmencerry</SelectItem>
                      <SelectItem value="jayanagar">Jayanagar</SelectItem>
                      <SelectItem value="ameerpet">Ameerpet</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Institution Information */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-2">
                  <Label htmlFor="institutionType" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Institution Type
                  </Label>
                  <Select
                    value={formData.institutionType}
                    onValueChange={(value) => setFormData({ ...formData, institutionType: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select institution type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="private">Private</SelectItem>
                      <SelectItem value="government">Government</SelectItem>
                      <SelectItem value="autonomous">Autonomous</SelectItem>
                      <SelectItem value="deemed">Deemed University</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="university" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    University
                  </Label>
                  <Select
                    value={formData.university}
                    onValueChange={(value) => setFormData({ ...formData, university: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select university" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="anna-university">Anna University</SelectItem>
                      <SelectItem value="jntu">JNTU</SelectItem>
                      <SelectItem value="vtu">VTU</SelectItem>
                      <SelectItem value="srm">SRM Institute</SelectItem>
                      <SelectItem value="amrita">Amrita</SelectItem>
                      <SelectItem value="manipal">Manipal</SelectItem>
                      <SelectItem value="others">Others</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="yearAdmission" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Year of Admission / Graduation
                  </Label>
                  <Select
                    value={formData.yearAdmission}
                    onValueChange={(value) => setFormData({ ...formData, yearAdmission: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2019">2019</SelectItem>
                      <SelectItem value="2020">2020</SelectItem>
                      <SelectItem value="2021">2021</SelectItem>
                      <SelectItem value="2022">2022</SelectItem>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2025">2025</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="modeOfStudy" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Mode of Study
                  </Label>
                  <Select
                    value={formData.modeOfStudy}
                    onValueChange={(value) => setFormData({ ...formData, modeOfStudy: value })}
                  >
                    <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white">
                      <SelectValue placeholder="Select mode" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="online">Online</SelectItem>
                      <SelectItem value="offline">Offline</SelectItem>
                      <SelectItem value="hybrid">Hybrid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Areas of Interest */}
              <div className="space-y-3">
                <Label className="text-sm font-medium text-gray-700 dark:text-gray-300">Areas of Interest</Label>
                <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                  {[
                    "AI/ML",
                    "Deep Learning",
                    "Data Analytics",
                    "Python",
                    "R Programming",
                    "Power BI",
                    "TensorFlow",
                    "ROS",
                    "Jetson Nano",
                    "FPGA",
                  ].map((interest) => (
                    <div key={interest} className="flex items-center space-x-2">
                      <Checkbox
                        id={interest}
                        checked={formData.areasOfInterest.includes(interest)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData({
                              ...formData,
                              areasOfInterest: [...formData.areasOfInterest, interest],
                            })
                          } else {
                            setFormData({
                              ...formData,
                              areasOfInterest: formData.areasOfInterest.filter((item: string) => item !== interest),
                            })
                          }
                        }}
                      />
                      <Label htmlFor={interest} className="text-sm text-gray-700 dark:text-gray-300">
                        {interest}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  Additional Notes
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Enter any additional information..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                />
              </div>

              {/* Submit Button */}
              <div className="flex items-center justify-end gap-3 pt-6 border-t border-gray-200 dark:border-gray-700">
                <Button
                  variant="outline"
                  onClick={() => setShowCreateForm(false)}
                  className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white"
                  onClick={(e) => {
                    e.preventDefault()
                    toast({
                      title: "Lead Created",
                      description: "New lead has been successfully added to your pipeline.",
                    })
                    setShowCreateForm(false)
                  }}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Submit Lead
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Section 3: Bulk Upload Template - Enhanced */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardHeader className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <CardTitle className="text-lg text-gray-900 dark:text-white">📁 Bulk Upload Template</CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-400">
            Upload CSV files or download templates for bulk lead imports
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {/* Download Options */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-6">
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  toast({
                    title: "Template Downloaded",
                    description: "Sample CSV template has been downloaded to your device.",
                  })
                }}
                className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
              >
                <Download className="h-4 w-4 mr-2" />📄 Download as Excel (CSV)
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  toast({
                    title: "PDF Template Downloaded",
                    description: "Sample PDF template has been downloaded to your device.",
                  })
                }}
                className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
              >
                <Download className="h-4 w-4 mr-2" />🧾 Download as PDF
              </Button>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Only .csv upload is supported. Use the sample template for formatting.
            </p>
          </div>

          {/* File Upload Area */}
          <div className="space-y-4">
            <div
              className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
                isDragOver || dragActive
                  ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-950/20 scale-[1.02]"
                  : uploadError
                    ? "border-red-300 dark:border-red-600 bg-red-50 dark:bg-red-950/20"
                    : "border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500"
              }`}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
            >
              <input
                type="file"
                accept=".csv"
                onChange={handleFileInputChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                id="file-upload"
              />

              <div className="space-y-4">
                {uploadError ? (
                  <AlertCircle className="h-12 w-12 mx-auto text-red-500" />
                ) : uploadedFile ? (
                  <FileCheck className="h-12 w-12 mx-auto text-green-500" />
                ) : (
                  <CloudUpload
                    className={`h-12 w-12 mx-auto transition-colors ${
                      isDragOver ? "text-indigo-500" : "text-gray-400 dark:text-gray-500"
                    }`}
                  />
                )}

                <div>
                  {uploadedFile ? (
                    <div className="space-y-2">
                      <h3 className="text-lg font-medium text-green-700 dark:text-green-400">
                        File Uploaded Successfully!
                      </h3>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        <p className="font-medium">{uploadedFile.name}</p>
                        <p>{formatFileSize(uploadedFile.size)}</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setUploadedFile(null)
                          setUploadError("")
                        }}
                        className="mt-2"
                      >
                        Upload Different File
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                        {isDragOver ? "Drop your CSV file here" : "Upload CSV File"}
                      </h3>
                      <p className="text-gray-600 dark:text-gray-400">
                        Drag and drop your CSV file here, or click to browse
                      </p>
                      <div className="flex items-center justify-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                        <span>Supported format:</span>
                        <Badge variant="outline" className="text-xs">
                          CSV
                        </Badge>
                        <span>•</span>
                        <span>Max size: 10MB</span>
                      </div>
                    </div>
                  )}
                </div>

                {!uploadedFile && (
                  <Button
                    variant="outline"
                    className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 bg-transparent"
                  >
                    Browse Files
                  </Button>
                )}
              </div>
            </div>

            {/* Error Message */}
            {uploadError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{uploadError}</AlertDescription>
              </Alert>
            )}

            {/* Process Upload Button */}
            {uploadedFile && !uploadError && (
              <div className="flex justify-center">
                <Button
                  onClick={() => {
                    toast({
                      title: "Processing Upload",
                      description: `Processing ${uploadedFile.name} and importing leads...`,
                    })
                    // Reset after processing
                    setTimeout(() => {
                      setUploadedFile(null)
                      toast({
                        title: "Import Complete",
                        description: "Successfully imported 25 new leads from your CSV file.",
                      })
                    }, 2000)
                  }}
                  className="bg-green-600 hover:bg-green-700 dark:bg-green-500 dark:hover:bg-green-600 text-white"
                >
                  <FileUp className="h-4 w-4 mr-2" />
                  Process Upload
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Section 4: Recent Lead Additions - Filterable Data Table */}
      <Card className="border border-gray-200 dark:border-gray-700">
        <CardHeader className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <CardTitle className="text-lg text-gray-900 dark:text-white">Recent Lead Additions</CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-400">
            Manage and filter your lead database with advanced search and tag filtering
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          {/* Filter Options */}
          <div className="space-y-4 mb-6">
            {/* Search and Date Range */}
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search Bar */}
              <div className="flex-1">
                <div className="relative flex">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 dark:text-gray-500" />
                    <Input
                      placeholder="Search by name, college, department, event..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 pr-4 border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-r-none border-r-0"
                    />
                  </div>
                  <Button
                    onClick={() => {
                      // Search functionality is already handled by the onChange event
                      toast({
                        title: "Search Applied",
                        description: `Searching for: "${searchQuery}"`,
                      })
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white rounded-l-none px-4"
                    disabled={!searchQuery.trim()}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Date Range Filter */}
              <div className="flex gap-2">
                {datePresets.map((preset) => (
                  <Button
                    key={preset.label}
                    variant="outline"
                    size="sm"
                    onClick={() => handleDatePreset(preset.days)}
                    className="whitespace-nowrap border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                  >
                    {preset.label}
                  </Button>
                ))}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2 bg-transparent border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      <CalendarIcon className="h-4 w-4" />
                      Custom Range
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="end">
                    <Calendar
                      initialFocus
                      mode="range"
                      defaultMonth={dateRange?.from}
                      selected={dateRange}
                      onSelect={setDateRange}
                      numberOfMonths={2}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Selected Tags Display */}
            {selectedTags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Active Filters:</span>
                {selectedTags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="flex items-center gap-1 bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200"
                  >
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="ml-1 hover:bg-indigo-200 dark:hover:bg-indigo-800 rounded-full p-0.5"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedTags([])}
                  className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                >
                  Clear All
                </Button>
              </div>
            )}

            {/* Tag Filters */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Filter by Tags:</span>
              </div>

              {Object.entries(tagCategories).map(([categoryKey, category]) => (
                <Collapsible
                  key={categoryKey}
                  open={expandedCategories.includes(categoryKey)}
                  onOpenChange={() => toggleCategory(categoryKey)}
                >
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="ghost"
                      className="flex items-center justify-between w-full p-2 text-left hover:bg-gray-100 dark:hover:bg-gray-800"
                    >
                      <span className="font-medium text-gray-700 dark:text-gray-300">{category.title}</span>
                      {expandedCategories.includes(categoryKey) ? (
                        <ChevronUp className="h-4 w-4" />
                      ) : (
                        <ChevronDown className="h-4 w-4" />
                      )}
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-2">
                    <div className="flex flex-wrap gap-2 p-2 bg-gray-50 dark:bg-gray-800 rounded-md">
                      {category.tags.map((tag) => (
                        <button
                          key={tag}
                          onClick={() => toggleTag(tag)}
                          className={`px-2 py-1 text-xs rounded-full border transition-colors ${
                            selectedTags.includes(tag)
                              ? "bg-indigo-600 text-white border-indigo-600"
                              : "bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-600"
                          }`}
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              ))}
            </div>
          </div>

          {/* Export Options */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                {filteredLeads.length} leads found
                {selectedLeads.length > 0 && ` (${selectedLeads.length} selected)`}
              </span>
              <div className="flex items-center space-x-2">
                <Checkbox id="include-tags" defaultChecked />
                <Label htmlFor="include-tags" className="text-sm text-gray-600 dark:text-gray-400">
                  Include Tag Metadata
                </Label>
              </div>
            </div>
            <Button
              onClick={handleExportCSV}
              disabled={filteredLeads.length === 0}
              className="bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 text-white"
            >
              <Download className="h-4 w-4 mr-2" />
              Export Filtered Data to CSV
            </Button>
          </div>

          {/* Data Table */}
          <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                  <tr>
                    <th className="px-4 py-3 text-left">
                      <Checkbox
                        checked={selectedLeads.length === currentLeads.length && currentLeads.length > 0}
                        onCheckedChange={handleSelectAll}
                      />
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Name
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Email
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Mobile
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Department
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Domain
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Event Type
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Tags
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Added On
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
                  {currentLeads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                      <td className="px-4 py-4">
                        <Checkbox
                          checked={selectedLeads.includes(lead.id)}
                          onCheckedChange={(checked) => handleSelectLead(lead.id, checked as boolean)}
                        />
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center">
                          <div>
                            <div className="text-sm font-medium text-gray-900 dark:text-white">{lead.name}</div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">{lead.college}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-sm text-gray-900 dark:text-white">{lead.email}</td>
                      <td className="px-4 py-4 text-sm text-gray-900 dark:text-white">{lead.mobile}</td>
                      <td className="px-4 py-4">
                        <Badge variant="outline" className="text-xs">
                          {lead.department}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant="secondary" className="text-xs">
                          {lead.domain}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant="default" className="text-xs">
                          {lead.eventType}
                        </Badge>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex flex-wrap gap-1 max-w-xs">
                          {lead.tags.slice(0, 3).map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {lead.tags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{lead.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-4 text-sm text-gray-500 dark:text-gray-400">
                        {format(new Date(lead.addedOn), "MMM dd, yyyy")}
                      </td>
                      <td className="px-4 py-4">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Lead
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete Lead
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="bg-gray-50 dark:bg-gray-800 px-4 py-3 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-700 dark:text-gray-300">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(currentPage * itemsPerPage, filteredLeads.length)} of {filteredLeads.length} results
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                      className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      Previous
                    </Button>
                    <span className="text-sm text-gray-700 dark:text-gray-300">
                      Page {currentPage} of {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages}
                      className="border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
                    >
                      Next
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
