"use client"

import * as React from "react"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import {
  Download,
  Upload,
  FileText,
  Moon,
  Sun,
  CalendarIcon,
  CheckCircle,
  Clock,
  AlertCircle,
  UserPlus,
  Rocket,
  Minimize2,
  X,
  Menu,
} from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { format } from "date-fns"
import {
  BarChart3,
  Bot,
  BrainCircuit,
  Database,
  Home,
  MessageSquare,
  Megaphone,
  Settings,
  Bell,
  User,
  Search,
  CalendarPlus2Icon as CalendarIcon2,
  Target,
  Users,
  MousePointer,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  Mail,
  Share2,
  PlusCircle,
  Play,
  Pause,
  MoreHorizontal,
} from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  LabelList,
} from "recharts"
import { DataManagementPage } from "./data-management-page"

// Updated KPI data with new educational metrics
const kpiData = [
  {
    title: "Total Leads",
    value: "2,847",
    change: "+12.5%",
    trend: "up",
    icon: UserPlus,
    color: "text-blue-600",
    description: "All leads added across all users",
  },
  {
    title: "Participant Distribution",
    value: "65% Students",
    change: "+5.2%",
    trend: "up",
    icon: Users,
    color: "text-purple-600",
    description: "Ratio of Staff vs Students per department",
  },
  {
    title: "Departmental Engagement",
    value: "8 Departments",
    change: "+2",
    trend: "up",
    icon: Database,
    color: "text-purple-600",
    description: "Number of participants per department",
  },
  {
    title: "Batch-wise Activity",
    value: "2021-2025: 45%",
    change: "+8.3%",
    trend: "up",
    icon: CalendarIcon2,
    color: "text-purple-600",
    description: "Events attended per batch, learning outcomes by year",
  },
  {
    title: "Event Reach",
    value: "156 Events",
    change: "+23.1%",
    trend: "up",
    icon: Target,
    color: "text-orange-600",
    description: "Total registrations per event type (Workshop, Referral, Campus Drive)",
  },
  {
    title: "Regional Participation",
    value: "Tamil Nadu: 42%",
    change: "+6.7%",
    trend: "up",
    icon: MousePointer,
    color: "text-teal-600",
    description: "Heatmap of registrations by city, state, country",
  },
  {
    title: "Localization Score",
    value: "78%",
    change: "+4.2%",
    trend: "up",
    icon: Activity,
    color: "text-teal-600",
    description: "Customized interest alignment by region",
  },
  {
    title: "International Outreach",
    value: "12% Global",
    change: "+2.8%",
    trend: "up",
    icon: Megaphone,
    color: "text-teal-600",
    description: "Cross-country engagement percentages",
  },
  {
    title: "Tech Interest Popularity",
    value: "AI/ML: 68%",
    change: "+15.4%",
    trend: "up",
    icon: Bot,
    color: "text-yellow-600",
    description: "Frequency of selected domains (AI, VLSI, Power BI, etc.)",
  },
  {
    title: "Domain-Event Matching",
    value: "85% Match",
    change: "+7.1%",
    trend: "up",
    icon: Zap,
    color: "text-yellow-600",
    description: "Correlation between interest area and event type",
  },
]

const funnelData = [
  { name: "Cold Leads", value: 1000, fill: "#ef4444" },
  { name: "Warm Leads", value: 600, fill: "#f97316" },
  { name: "Hot Leads", value: 300, fill: "#eab308" },
  { name: "Converted", value: 120, fill: "#22c55e" },
]

const sourceData = [
  { name: "Website", value: 35, fill: "#3b82f6" },
  { name: "Social Media", value: 25, fill: "#8b5cf6" },
  { name: "Email", value: 20, fill: "#10b981" },
  { name: "Ads", value: 15, fill: "#f59e0b" },
  { name: "Referral", value: 5, fill: "#ef4444" },
]

const conversionTrends = [
  { month: "Jan", conversions: 65, leads: 1200 },
  { month: "Feb", conversions: 78, leads: 1350 },
  { month: "Mar", conversions: 92, leads: 1480 },
  { month: "Apr", conversions: 85, leads: 1320 },
  { month: "May", conversions: 108, leads: 1650 },
  { month: "Jun", conversions: 125, leads: 1800 },
]

const campaignData = [
  { name: "Summer Sale", channel: "Email", status: "Active", engagement: 85, ctr: "3.2%" },
  { name: "Product Launch", channel: "Social", status: "Scheduled", engagement: 0, ctr: "0%" },
  { name: "Retargeting", channel: "Ads", status: "Active", engagement: 72, ctr: "2.8%" },
  { name: "Newsletter", channel: "Email", status: "Paused", engagement: 45, ctr: "1.9%" },
]

const recentLeads = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.j@email.com",
    source: "Website",
    status: "Hot",
    assignedTo: "John Smith",
    createdAt: "2024-01-15T10:30:00Z",
    score: 85,
  },
  {
    id: 2,
    name: "Mike Chen",
    email: "mike.chen@company.com",
    source: "LinkedIn",
    status: "Warm",
    assignedTo: "Emma Davis",
    createdAt: "2024-01-15T09:15:00Z",
    score: 72,
  },
  {
    id: 3,
    name: "Lisa Rodriguez",
    email: "lisa.r@startup.io",
    source: "Referral",
    status: "Cold",
    assignedTo: "Alex Wilson",
    createdAt: "2024-01-15T08:45:00Z",
    score: 45,
  },
  {
    id: 4,
    name: "David Park",
    email: "d.park@tech.com",
    source: "Google Ads",
    status: "Hot",
    assignedTo: "John Smith",
    createdAt: "2024-01-14T16:20:00Z",
    score: 91,
  },
  {
    id: 5,
    name: "Anna Thompson",
    email: "anna.t@business.com",
    source: "Email Campaign",
    status: "Warm",
    assignedTo: "Emma Davis",
    createdAt: "2024-01-14T14:10:00Z",
    score: 68,
  },
]

const recentNotifications = [
  {
    id: 1,
    type: "lead",
    title: "New lead added",
    description: "Sarah Johnson from Website",
    time: "2 minutes ago",
    icon: UserPlus,
    color: "text-green-600",
  },
  {
    id: 2,
    type: "campaign",
    title: "Campaign launched",
    description: "Summer Sale email campaign is now active",
    time: "1 hour ago",
    icon: Rocket,
    color: "text-blue-600",
  },
  {
    id: 3,
    type: "task",
    title: "Follow-up reminder",
    description: "Call Mike Chen - scheduled for 2 PM",
    time: "3 hours ago",
    icon: Clock,
    color: "text-orange-600",
  },
  {
    id: 4,
    type: "alert",
    title: "Low conversion rate",
    description: "Facebook Ads campaign needs attention",
    time: "5 hours ago",
    icon: AlertCircle,
    color: "text-red-600",
  },
]

const salesTasks = [
  {
    id: 1,
    task: "Follow up with Sarah Johnson",
    priority: "High",
    dueDate: "Today",
    assignee: "John Smith",
    status: "pending",
  },
  {
    id: 2,
    task: "Send proposal to Mike Chen",
    priority: "Medium",
    dueDate: "Tomorrow",
    assignee: "Emma Davis",
    status: "pending",
  },
  {
    id: 3,
    task: "Schedule demo with Lisa Rodriguez",
    priority: "Low",
    dueDate: "This Week",
    assignee: "Alex Wilson",
    status: "completed",
  },
]

const teamMembers = [
  { id: "all", name: "All Team Members" },
  { id: "john", name: "John Smith" },
  { id: "emma", name: "Emma Davis" },
  { id: "alex", name: "Alex Wilson" },
]

const sidebarNavigation = [
  {
    title: "Main",
    items: [
      { title: "Dashboard", icon: Home, url: "dashboard" },
      { title: "Lead Management", icon: Database, url: "data" },
      { title: "Reports & Insights", icon: BarChart3, url: "reports" },
    ],
  },
  {
    title: "Tools",
    items: [
      { title: "AI Content Generator", icon: Bot, url: "ai-content" },
      { title: "Campaigns", icon: Megaphone, url: "campaigns" },
      { title: "Chat with Data", icon: MessageSquare, url: "chat" },
    ],
  },
  {
    title: "Settings",
    items: [{ title: "Settings", icon: Settings, url: "settings" }],
  },
]

export function MarketingDashboard() {
  const [activeSection, setActiveSection] = React.useState("dashboard")
  const [chatMessages, setChatMessages] = React.useState([
    {
      role: "assistant",
      content:
        "Hello! I can help you analyze your marketing data. Try asking me about your leads, campaigns, or conversion rates.",
    },
  ])
  const [chatInput, setChatInput] = React.useState("")

  const [darkMode, setDarkMode] = React.useState(false)
  const [dateRange, setDateRange] = React.useState({ from: new Date(2024, 0, 1), to: new Date() })
  const [selectedTeamMember, setSelectedTeamMember] = React.useState("all")
  const [searchQuery, setSearchQuery] = React.useState("")
  const [showAIAssistant, setShowAIAssistant] = React.useState(false)
  const [aiMinimized, setAiMinimized] = React.useState(false)
  const [filteredLeads, setFilteredLeads] = React.useState(recentLeads)
  const [sidebarOpen, setSidebarOpen] = React.useState(false)

  const [showCreateForm, setShowCreateForm] = React.useState(false)
  const [formData, setFormData] = React.useState({
    staffStudent: "",
    college: "",
    department: "",
    batch: "",
    domain: "",
    eventSource: "",
    state: "",
    country: "",
    institutionType: "",
    university: "",
    yearAdmission: "",
    modeOfStudy: "",
    areasOfInterest: [],
    eventType: "",
    cityDistrict: "",
    branch: "",
    name: "",
    email: "",
    phone: "",
    notes: "",
  })
  const [dragActive, setDragActive] = React.useState(false)

  // New state variables for filters, tags, and table management
  const [categoryFilter, setCategoryFilter] = React.useState("")
  const [departmentFilter, setDepartmentFilter] = React.useState("")
  const [batchFilter, setBatchFilter] = React.useState("")
  const [domainFilter, setDomainFilter] = React.useState("")
  const [selectedTags, setSelectedTags] = React.useState<string[]>([])
  const [sortColumn, setSortColumn] = React.useState<string | null>(null)
  const [sortDirection, setSortDirection] = React.useState<"asc" | "desc">("asc")

  // Filter leads based on search query
  React.useEffect(() => {
    const filtered = recentLeads.filter(
      (lead) =>
        lead.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lead.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lead.source.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    setFilteredLeads(filtered)
  }, [searchQuery])

  // Toast notifications for demo
  React.useEffect(() => {
    const interval = setInterval(() => {
      const notifications = [
        "New lead added: Sarah Johnson",
        "Campaign launched: Summer Sale",
        "Follow-up reminder: Mike Chen",
        "Conversion rate improved by 2.3%",
      ]
      const randomNotification = notifications[Math.floor(Math.random() * notifications.length)]
      toast({
        title: "Real-time Update",
        description: randomNotification,
      })
    }, 30000) // Show toast every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const handleExportCSV = () => {
    toast({
      title: "Export Started",
      description: "Your CSV file is being prepared for download.",
    })
  }

  const handleUploadLeads = () => {
    toast({
      title: "Upload Ready",
      description: "Select a CSV file to upload leads.",
    })
  }

  const toggleTheme = () => {
    setDarkMode(!darkMode)
    document.documentElement.classList.toggle("dark")
    toast({
      title: darkMode ? "Light Mode" : "Dark Mode",
      description: `Switched to ${darkMode ? "light" : "dark"} mode.`,
    })
  }

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!chatInput.trim()) return

    const newMessages = [
      ...chatMessages,
      { role: "user", content: chatInput },
      {
        role: "assistant",
        content: `Based on your query "${chatInput}", here's what I found: Your top performing campaigns this month are Summer Sale (85% engagement) and Retargeting (72% engagement). Would you like me to dive deeper into any specific metrics?`,
      },
    ]
    setChatMessages(newMessages)
    setChatInput("")
  }

  return (
    <div className="flex min-h-screen bg-background">
      {/* Fixed Sidebar - Desktop */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 z-50">
        <div className="flex flex-col flex-grow bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 overflow-y-auto">
          {/* Logo/Brand */}
          <div className="flex items-center flex-shrink-0 px-4 py-6 border-b border-gray-200 dark:border-gray-700">
            <button
              onClick={() => setActiveSection("dashboard")}
              className="flex items-center gap-3 hover:opacity-80 transition-opacity"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg overflow-hidden bg-white">
                <img src="/images/pantech-logo.png" alt="Pantech leadCraft" className="h-8 w-8 object-contain" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-gray-900 dark:text-white">Pantech leadCraft</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">Analytics Dashboard</span>
              </div>
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-6 space-y-8">
            {sidebarNavigation.map((group) => (
              <div key={group.title}>
                <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  {group.title}
                </h3>
                <div className="mt-3 space-y-1">
                  {group.items.map((item) => (
                    <button
                      key={item.title}
                      onClick={() => setActiveSection(item.url)}
                      className={`group flex items-center px-3 py-2 text-sm font-medium rounded-md w-full text-left transition-colors ${
                        activeSection === item.url
                          ? "bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-200"
                          : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white"
                      }`}
                    >
                      <item.icon
                        className={`mr-3 h-5 w-5 flex-shrink-0 ${
                          activeSection === item.url
                            ? "text-indigo-500 dark:text-indigo-300"
                            : "text-gray-400 dark:text-gray-500 group-hover:text-gray-500 dark:group-hover:text-gray-400"
                        }`}
                      />
                      {item.title}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </nav>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setSidebarOpen(false)} />
          <div className="relative flex flex-col w-full max-w-xs bg-white dark:bg-gray-900 shadow-xl">
            <div className="absolute top-0 right-0 -mr-12 pt-2">
              <button
                type="button"
                className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="h-6 w-6 text-white" />
              </button>
            </div>

            {/* Mobile Logo/Brand */}
            <div className="flex items-center flex-shrink-0 px-4 py-6 border-b border-gray-200 dark:border-gray-700">
              <button
                onClick={() => {
                  setActiveSection("dashboard")
                  setSidebarOpen(false)
                }}
                className="flex items-center gap-3 hover:opacity-80 transition-opacity"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg overflow-hidden bg-indigo-600">
                  <img src="/images/pantech-logo.png" alt="Pantech leadCraft" className="h-8 w-8 object-contain" />
                </div>
                <div className="flex flex-col">
                  <span className="text-lg font-bold text-gray-900 dark:text-white">Pantech leadCraft</span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">Analytics Dashboard</span>
                </div>
              </button>
            </div>

            {/* Mobile Navigation */}
            <nav className="flex-1 px-4 py-6 space-y-8 overflow-y-auto">
              {sidebarNavigation.map((group) => (
                <div key={group.title}>
                  <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    {group.title}
                  </h3>
                  <div className="mt-3 space-y-1">
                    {group.items.map((item) => (
                      <button
                        key={item.title}
                        onClick={() => {
                          setActiveSection(item.url)
                          setSidebarOpen(false)
                        }}
                        className={`group flex items-center px-3 py-2 text-sm font-medium rounded-md w-full text-left transition-colors ${
                          activeSection === item.url
                            ? "bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-200"
                            : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white"
                        }`}
                      >
                        <item.icon
                          className={`mr-3 h-5 w-5 flex-shrink-0 ${
                            activeSection === item.url
                              ? "text-indigo-500 dark:text-indigo-300"
                              : "text-gray-400 dark:text-gray-500 group-hover:text-gray-500 dark:group-hover:text-gray-400"
                          }`}
                        />
                        {item.title}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </nav>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex flex-col flex-1 md:pl-64">
        {/* Top Header */}
        <header className="sticky top-0 z-40 flex h-16 flex-shrink-0 items-center justify-between border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 px-4 shadow-sm text-black">
          <div className="flex items-center gap-4">
            {/* Mobile menu button */}
            <button
              type="button"
              className="md:hidden -ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-6 w-6" />
            </button>

            <div className="flex items-center gap-2">
              
            </div>
          </div>

          <div className="flex items-center gap-2 text-black">
            {/* Date Range Filter */}
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                  <CalendarIcon className="h-4 w-4" />
                  <span className="hidden sm:inline">
                    {dateRange?.from ? (
                      dateRange.to ? (
                        <>
                          {format(dateRange.from, "LLL dd")} - {format(dateRange.to, "LLL dd")}
                        </>
                      ) : (
                        format(dateRange.from, "LLL dd, y")
                      )
                    ) : (
                      "Pick a date range"
                    )}
                  </span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  initialFocus
                  mode="range"
                  defaultMonth={dateRange?.from}
                  selected={dateRange}
                  onSelect={setDateRange}
                  numberOfMonths={2}
                />
              </PopoverContent>
            </Popover>

            {/* Team Member Filter - Hidden on mobile */}
            <div className="hidden sm:block">
              <Select value={selectedTeamMember} onValueChange={setSelectedTeamMember}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select team member" />
                </SelectTrigger>
                <SelectContent>
                  {teamMembers.map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Theme Toggle */}
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>

            <Button variant="ghost" size="icon">
              <Bell className="h-4 w-4" />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Profile</DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem>Logout</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-900">
          <div className="px-6 py-6 space-y-6">
            {/* Data Management Section */}
            {activeSection === "data" && (
              <DataManagementPage
                showCreateForm={showCreateForm}
                setShowCreateForm={setShowCreateForm}
                formData={formData}
                setFormData={setFormData}
                dragActive={dragActive}
                setDragActive={setDragActive}
              />
            )}

            {/* KPI Cards Section */}
            {(activeSection === "dashboard" || activeSection === "reports") && (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
                {kpiData.map((kpi, index) => (
                  <Card key={index} className="hover:shadow-md transition-shadow group relative">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{kpi.title}</CardTitle>
                      <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{kpi.value}</div>
                      <div className="flex items-center text-xs text-muted-foreground">
                        {kpi.trend === "up" ? (
                          <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
                        )}
                        <span className={kpi.trend === "up" ? "text-green-500" : "text-red-500"}>{kpi.change}</span>
                        <span className="ml-1">from last month</span>
                      </div>
                    </CardContent>
                    {/* Tooltip for description */}
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-black text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-10">
                      {kpi.description}
                      <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-black"></div>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {/* Reports & Charts Section */}
            {(activeSection === "dashboard" || activeSection === "reports") && (
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Lead Funnel</CardTitle>
                    <CardDescription>Track lead progress through stages</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer
                      config={{
                        value: { label: "Leads", color: "hsl(var(--chart-1))" },
                      }}
                      className="h-[300px]"
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={funnelData} layout="horizontal">
                          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                          <XAxis type="number" className="text-foreground" />
                          <YAxis dataKey="name" type="category" width={80} className="text-foreground font-medium" />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <Bar dataKey="value" fill="var(--color-value)" />
                        </BarChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Lead Sources</CardTitle>
                    <CardDescription>Breakdown by acquisition channel</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer
                      config={{
                        value: { label: "Percentage", color: "hsl(var(--chart-1))" },
                      }}
                      className="h-[300px]"
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={sourceData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={120}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            {sourceData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                            <LabelList
                              dataKey="name"
                              position="outside"
                              className="fill-foreground text-sm font-medium"
                            />
                          </Pie>
                          <ChartTooltip content={<ChartTooltipContent />} />
                        </PieChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </CardContent>
                </Card>

                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle>Conversion Trends</CardTitle>
                    <CardDescription>Monthly conversion performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ChartContainer
                      config={{
                        conversions: { label: "Conversions", color: "hsl(var(--chart-1))" },
                        leads: { label: "Leads", color: "hsl(var(--chart-2))" },
                      }}
                      className="h-[300px]"
                    >
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={conversionTrends}>
                          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                          <XAxis dataKey="month" className="text-foreground" />
                          <YAxis className="text-foreground" />
                          <ChartTooltip content={<ChartTooltipContent />} />
                          <ChartLegend content={<ChartLegendContent className="text-foreground" />} />
                          <Line
                            type="monotone"
                            dataKey="conversions"
                            stroke="var(--color-conversions)"
                            strokeWidth={2}
                          />
                          <Line type="monotone" dataKey="leads" stroke="var(--color-leads)" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </ChartContainer>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Enhanced Data Insights & Reports Section */}
            {(activeSection === "dashboard" || activeSection === "reports") && (
              <div className="space-y-6">
                {/* Export/Action Buttons */}
                <div className="flex items-center justify-between text-white">
                  <h2 className="text-xl font-semibold">Data Insights & Reports</h2>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={handleExportCSV}>
                      <Download className="h-4 w-4 mr-2" />
                      Export CSV
                    </Button>
                    <Button variant="outline" size="sm">
                      <FileText className="h-4 w-4 mr-2" />
                      View Reports
                    </Button>
                    <Button variant="outline" size="sm" onClick={handleUploadLeads}>
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Leads
                    </Button>
                  </div>
                </div>

                {/* Recent Leads Table */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>Recent Lead Additions</CardTitle>
                        <CardDescription>Latest leads added to your pipeline</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Input
                          placeholder="Search leads..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-64"
                        />
                        <Button variant="outline" size="icon">
                          <Search className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-2 font-medium">Name</th>
                            <th className="text-left p-2 font-medium">Source</th>
                            <th className="text-left p-2 font-medium">Status</th>
                            <th className="text-left p-2 font-medium">Score</th>
                            <th className="text-left p-2 font-medium">Assigned To</th>
                            <th className="text-left p-2 font-medium">Created</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredLeads.map((lead) => (
                            <tr key={lead.id} className="border-b hover:bg-muted/50">
                              <td className="p-2">
                                <div>
                                  <div className="font-medium">{lead.name}</div>
                                  <div className="text-sm text-muted-foreground">{lead.email}</div>
                                </div>
                              </td>
                              <td className="p-2">
                                <Badge variant="outline">{lead.source}</Badge>
                              </td>
                              <td className="p-2">
                                <Badge
                                  variant={
                                    lead.status === "Hot"
                                      ? "destructive"
                                      : lead.status === "Warm"
                                        ? "default"
                                        : "secondary"
                                  }
                                >
                                  {lead.status}
                                </Badge>
                              </td>
                              <td className="p-2">
                                <div className="flex items-center gap-2">
                                  <Progress value={lead.score} className="w-16" />
                                  <span className="text-sm font-medium">{lead.score}</span>
                                </div>
                              </td>
                              <td className="p-2 text-sm">{lead.assignedTo}</td>
                              <td className="p-2 text-sm">{format(new Date(lead.createdAt), "MMM dd, HH:mm")}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>

                {/* Activity Feed & Tasks Row */}
                <div className="grid gap-6 md:grid-cols-2">
                  {/* Recent Notifications */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Bell className="h-5 w-5" />
                        Recent Notifications
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {recentNotifications.map((notification) => (
                          <div
                            key={notification.id}
                            className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50"
                          >
                            <notification.icon className={`h-5 w-5 mt-0.5 ${notification.color}`} />
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm">{notification.title}</p>
                              <p className="text-sm text-muted-foreground">{notification.description}</p>
                              <p className="text-xs text-muted-foreground mt-1">{notification.time}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Sales Tasks */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <CheckCircle className="h-5 w-5" />
                        Sales Tasks
                      </CardTitle>
                      <CardDescription>Pending follow-ups and actions</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {salesTasks.map((task) => (
                          <div key={task.id} className="flex items-center gap-3 p-2 rounded-lg border">
                            <div
                              className={`h-2 w-2 rounded-full ${
                                task.status === "completed"
                                  ? "bg-green-500"
                                  : task.priority === "High"
                                    ? "bg-red-500"
                                    : task.priority === "Medium"
                                      ? "bg-yellow-500"
                                      : "bg-blue-500"
                              }`}
                            />
                            <div className="flex-1 min-w-0">
                              <p
                                className={`font-medium text-sm ${task.status === "completed" ? "line-through text-muted-foreground" : ""}`}
                              >
                                {task.task}
                              </p>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {task.priority}
                                </Badge>
                                <span className="text-xs text-muted-foreground">{task.dueDate}</span>
                                <span className="text-xs text-muted-foreground">• {task.assignee}</span>
                              </div>
                            </div>
                            <Button variant="ghost" size="sm">
                              {task.status === "completed" ? (
                                <CheckCircle className="h-4 w-4 text-green-500" />
                              ) : (
                                <Clock className="h-4 w-4" />
                              )}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* AI Content Generator */}
            {activeSection === "ai-content" && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bot className="h-5 w-5" />
                      AI Content Generator
                    </CardTitle>
                    <CardDescription>
                      Generate marketing content using AI for ads, emails, and social media
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="ad-copy" className="w-full">
                      <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="ad-copy">Ad Copy</TabsTrigger>
                        <TabsTrigger value="email">Email</TabsTrigger>
                        <TabsTrigger value="social">Social Media</TabsTrigger>
                        <TabsTrigger value="drip">Drip Campaign</TabsTrigger>
                      </TabsList>

                      <TabsContent value="ad-copy" className="space-y-4">
                        <div className="grid gap-4">
                          <div>
                            <Label htmlFor="product">Product/Service</Label>
                            <Input id="product" placeholder="Enter your product or service" />
                          </div>
                          <div>
                            <Label htmlFor="audience">Target Audience</Label>
                            <Input id="audience" placeholder="Describe your target audience" />
                          </div>
                          <div>
                            <Label htmlFor="tone">Tone</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select tone" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="professional">Professional</SelectItem>
                                <SelectItem value="casual">Casual</SelectItem>
                                <SelectItem value="urgent">Urgent</SelectItem>
                                <SelectItem value="friendly">Friendly</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button className="w-full">
                            <Zap className="h-4 w-4 mr-2" />
                            Generate Ad Copy
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="email" className="space-y-4">
                        <div className="grid gap-4">
                          <div>
                            <Label htmlFor="subject">Email Subject</Label>
                            <Input id="subject" placeholder="Enter email subject" />
                          </div>
                          <div>
                            <Label htmlFor="goal">Campaign Goal</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select goal" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="sales">Drive Sales</SelectItem>
                                <SelectItem value="engagement">Increase Engagement</SelectItem>
                                <SelectItem value="awareness">Brand Awareness</SelectItem>
                                <SelectItem value="retention">Customer Retention</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button className="w-full">
                            <Mail className="h-4 w-4 mr-2" />
                            Generate Email Template
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="social" className="space-y-4">
                        <div className="grid gap-4">
                          <div>
                            <Label htmlFor="platform">Platform</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select platform" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="instagram">Instagram</SelectItem>
                                <SelectItem value="facebook">Facebook</SelectItem>
                                <SelectItem value="twitter">Twitter</SelectItem>
                                <SelectItem value="linkedin">LinkedIn</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="content-type">Content Type</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select content type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="post">Regular Post</SelectItem>
                                <SelectItem value="story">Story</SelectItem>
                                <SelectItem value="reel">Reel/Video</SelectItem>
                                <SelectItem value="carousel">Carousel</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button className="w-full">
                            <Share2 className="h-4 w-4 mr-2" />
                            Generate Social Post
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="drip" className="space-y-4">
                        <div className="grid gap-4">
                          <div>
                            <Label htmlFor="sequence">Campaign Sequence</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select sequence type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="welcome">Welcome Series</SelectItem>
                                <SelectItem value="nurture">Lead Nurture</SelectItem>
                                <SelectItem value="onboarding">Onboarding</SelectItem>
                                <SelectItem value="reengagement">Re-engagement</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="emails">Number of Emails</Label>
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select number" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="3">3 Emails</SelectItem>
                                <SelectItem value="5">5 Emails</SelectItem>
                                <SelectItem value="7">7 Emails</SelectItem>
                                <SelectItem value="10">10 Emails</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Button className="w-full">
                            <Activity className="h-4 w-4 mr-2" />
                            Generate Drip Campaign
                          </Button>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Campaign Manager */}
            {activeSection === "campaigns" && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold">Campaign Manager</h2>
                    <p className="text-muted-foreground">Build, schedule, and track your marketing campaigns</p>
                  </div>
                  <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    New Campaign
                  </Button>
                </div>

                <div className="grid gap-6">
                  {campaignData.map((campaign, index) => (
                    <Card key={index}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="flex items-center gap-2">
                              {campaign.name}
                              <Badge
                                variant={
                                  campaign.status === "Active"
                                    ? "default"
                                    : campaign.status === "Scheduled"
                                      ? "secondary"
                                      : "outline"
                                }
                              >
                                {campaign.status}
                              </Badge>
                            </CardTitle>
                            <CardDescription className="flex items-center gap-2">
                              {campaign.channel === "Email" && <Mail className="h-4 w-4" />}
                              {campaign.channel === "Social" && <Share2 className="h-4 w-4" />}
                              {campaign.channel === "Ads" && <Target className="h-4 w-4" />}
                              {campaign.channel}
                            </CardDescription>
                          </div>
                          <div className="flex items-center gap-2">
                            {campaign.status === "Active" ? (
                              <Button variant="outline" size="sm">
                                <Pause className="h-4 w-4 mr-2" />
                                Pause
                              </Button>
                            ) : (
                              <Button variant="outline" size="sm">
                                <Play className="h-4 w-4 mr-2" />
                                Start
                              </Button>
                            )}
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                <DropdownMenuItem>Edit</DropdownMenuItem>
                                <DropdownMenuItem>Duplicate</DropdownMenuItem>
                                <DropdownMenuItem>Archive</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid gap-4 md:grid-cols-3">
                          <div>
                            <Label className="text-sm text-muted-foreground">Engagement Rate</Label>
                            <div className="flex items-center gap-2 mt-1">
                              <Progress value={campaign.engagement} className="flex-1" />
                              <span className="text-sm font-medium">{campaign.engagement}%</span>
                            </div>
                          </div>
                          <div>
                            <Label className="text-sm text-muted-foreground">Click-through Rate</Label>
                            <div className="text-lg font-semibold mt-1">{campaign.ctr}</div>
                          </div>
                          <div>
                            <Label className="text-sm text-muted-foreground">Status</Label>
                            <div className="flex items-center gap-2 mt-1">
                              <div
                                className={`h-2 w-2 rounded-full ${
                                  campaign.status === "Active"
                                    ? "bg-green-500"
                                    : campaign.status === "Scheduled"
                                      ? "bg-blue-500"
                                      : "bg-gray-500"
                                }`}
                              />
                              <span className="text-sm">{campaign.status}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Chat with Data */}
            {activeSection === "chat" && (
              <div className="space-y-6">
                <Card className="h-[600px] flex flex-col">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BrainCircuit className="h-5 w-5" />
                      Chat with Your Data
                    </CardTitle>
                    <CardDescription>Ask questions about your marketing data in natural language</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    <div className="flex-1 space-y-4 overflow-y-auto mb-4">
                      {chatMessages.map((message, index) => (
                        <div
                          key={index}
                          className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-[80%] rounded-lg p-3 ${
                              message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <form onSubmit={handleChatSubmit} className="flex gap-2">
                      <Input
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="Ask about your marketing data..."
                        className="flex-1"
                      />
                      <Button type="submit">
                        <Search className="h-4 w-4" />
                      </Button>
                    </form>
                  </CardContent>
                </Card>

                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Sample Questions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left h-auto p-3 bg-transparent"
                        onClick={() => setChatInput("Show me top 5 converting sources last week")}
                      >
                        "Show me top 5 converting sources last week"
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left h-auto p-3 bg-transparent"
                        onClick={() => setChatInput("How many leads from Instagram this month?")}
                      >
                        "How many leads from Instagram this month?"
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left h-auto p-3 bg-transparent"
                        onClick={() => setChatInput("Top performing campaigns in Q2")}
                      >
                        "Top performing campaigns in Q2"
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left h-auto p-3 bg-transparent"
                        onClick={() => setChatInput("Compare email vs social media performance")}
                      >
                        "Compare email vs social media performance"
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Quick Insights</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex items-center justify-between p-2 bg-muted rounded">
                        <span className="text-sm">Best performing channel</span>
                        <Badge>Website (35%)</Badge>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-muted rounded">
                        <span className="text-sm">Highest conversion rate</span>
                        <Badge>Email campaigns (4.2%)</Badge>
                      </div>
                      <div className="flex items-center justify-between p-2 bg-muted rounded">
                        <span className="text-sm">Growth trend</span>
                        <Badge variant="secondary">+12.5% this month</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            {/* Mini AI Assistant */}
            {showAIAssistant && (
              <div
                className={`fixed bottom-4 right-4 z-50 transition-all duration-300 ${
                  aiMinimized ? "w-12 h-12" : "w-80 h-96"
                }`}
              >
                <Card className="h-full shadow-lg border-2">
                  {aiMinimized ? (
                    <CardContent className="p-0 h-full flex items-center justify-center">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setAiMinimized(false)}
                        className="h-full w-full rounded-lg"
                      >
                        <BrainCircuit className="h-6 w-6 text-primary" />
                      </Button>
                    </CardContent>
                  ) : (
                    <>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-sm flex items-center gap-2">
                            <BrainCircuit className="h-4 w-4" />
                            AI Assistant
                          </CardTitle>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setAiMinimized(true)}
                              className="h-6 w-6"
                            >
                              <Minimize2 className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setShowAIAssistant(false)}
                              className="h-6 w-6"
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="flex-1 flex flex-col p-3">
                        <div className="flex-1 bg-muted/30 rounded p-2 mb-2 text-xs">
                          <p className="font-medium mb-1">Weekly Performance Summary:</p>
                          <ul className="space-y-1 text-muted-foreground">
                            <li>• 47 new leads this week (+15%)</li>
                            <li>• Email campaigns: 3.2% CTR</li>
                            <li>• Top source: Website (35%)</li>
                            <li>• Conversion rate improved by 0.8%</li>
                          </ul>
                        </div>
                        <div className="flex gap-1">
                          <Input placeholder="Ask me anything..." className="text-xs h-8" />
                          <Button size="sm" className="h-8 px-2">
                            <Search className="h-3 w-3" />
                          </Button>
                        </div>
                      </CardContent>
                    </>
                  )}
                </Card>
              </div>
            )}

            {/* AI Assistant Toggle Button */}
            {!showAIAssistant && (
              <Button
                className="fixed bottom-4 right-4 z-50 rounded-full h-12 w-12 shadow-lg"
                onClick={() => setShowAIAssistant(true)}
              >
                <BrainCircuit className="h-6 w-6" />
              </Button>
            )}
          </div>
        </main>

        <Toaster />
      </div>

      {/* Mini AI Assistant - keeping existing functionality */}
      {showAIAssistant && (
        <div
          className={`fixed bottom-4 right-4 z-50 transition-all duration-300 ${
            aiMinimized ? "w-12 h-12" : "w-80 h-96"
          }`}
        >
          <Card className="h-full shadow-lg border-2">
            {aiMinimized ? (
              <CardContent className="p-0 h-full flex items-center justify-center">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setAiMinimized(false)}
                  className="h-full w-full rounded-lg"
                >
                  <BrainCircuit className="h-6 w-6 text-primary" />
                </Button>
              </CardContent>
            ) : (
              <>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <BrainCircuit className="h-4 w-4" />
                      AI Assistant
                    </CardTitle>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" onClick={() => setAiMinimized(true)} className="h-6 w-6">
                        <Minimize2 className="h-3 w-3" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setShowAIAssistant(false)} className="h-6 w-6">
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col p-3">
                  <div className="flex-1 bg-muted/30 rounded p-2 mb-2 text-xs">
                    <p className="font-medium mb-1">Weekly Performance Summary:</p>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• 47 new leads this week (+15%)</li>
                      <li>• Email campaigns: 3.2% CTR</li>
                      <li>• Top source: Website (35%)</li>
                      <li>• Conversion rate improved by 0.8%</li>
                    </ul>
                  </div>
                  <div className="flex gap-1">
                    <Input placeholder="Ask me anything..." className="text-xs h-8" />
                    <Button size="sm" className="h-8 px-2">
                      <Search className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </>
            )}
          </Card>
        </div>
      )}

      {/* AI Assistant Toggle Button */}
      {!showAIAssistant && (
        <Button
          className="fixed bottom-4 right-4 z-50 rounded-full h-12 w-12 shadow-lg"
          onClick={() => setShowAIAssistant(true)}
        >
          <BrainCircuit className="h-6 w-6" />
        </Button>
      )}
    </div>
  )
}
