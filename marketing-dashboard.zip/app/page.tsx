import { MarketingDashboard } from "@/components/marketing-dashboard"

export default function Home() {
  return <MarketingDashboard />
}
